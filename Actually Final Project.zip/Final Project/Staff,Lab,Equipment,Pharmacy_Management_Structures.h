
struct Staff {
    int id{};
    string name;
    string department;
    string shift;
};

struct Equipment {
    string name;
    string department;
    int quantity{};
};

struct LabResult {
    string patient_id;
    string test_type;
    string result;
    string technician;
    string date;
};

struct Medicine {
    string name;
    int quantity{};
};