struct billing {
    string patient_id;
    double amount{};
    string status;
};

struct Feedback {
    string user_id;
    string type;
    int rating{};
    string comment;
    string date;
};
