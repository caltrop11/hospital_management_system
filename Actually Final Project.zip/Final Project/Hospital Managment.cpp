#include <iostream>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <string>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <map>
#include <regex> //for date input validation
#include <limits>
#include <ctime>
#include "Patient_Managment_Structures.h"
#include "Staff,Lab,Equipment,Pharmacy_Management_Structures.h"
#include "Staff,Lab,Equipment,Pharmacy_Management_Functions.h"
#include "Billing_and_Feedback_Structures.h"
using namespace std;

// Function to trim leading and trailing whitespace
string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\r\n");
    size_t last = str.find_last_not_of(" \t\r\n");

    if (first == string::npos || last == string::npos)
        return "";

    return str.substr(first, last - first + 1);
}

int main() {
    constexpr int MAX_RECORDS = 100;
    patient patients[MAX_RECORDS];
    billing billings[MAX_RECORDS];
    int patient_count = 0, billing_count = 0;
    string patient_id, line;

    // Read patient records from file
    fstream patientCheck("Patient Record.txt", ios::in);
    if (patientCheck.is_open()) {
        getline(patientCheck, line); // Skip header
        while (getline(patientCheck, line)) {
            stringstream ss(line);
            getline(ss, patients[patient_count].name, '\t');
            patients[patient_count].name = trim(patients[patient_count].name);
            getline(ss, patients[patient_count].id, '\t');
            patients[patient_count].id = trim(patients[patient_count].id);
            ss >> patients[patient_count].age;
            patient_count++;
        }
        patientCheck.close();
    }

    // Read appointment file
    fstream appointmentCheck("Appointments.txt", ios::in);
    if (appointmentCheck.is_open()) {
        getline(appointmentCheck, line); // Skip header
        while (getline(appointmentCheck, line)) {
            stringstream ss(line);
            string pid, appt_date, appt_descr;
            getline(ss, pid, '\t');
            getline(ss, appt_date, '\t');
            getline(ss, appt_descr, '\t');

            // Remove trailing/leading whitespace (if any)
            pid.erase(remove(pid.begin(), pid.end(), ' '), pid.end());
            appt_date.erase(remove(appt_date.begin(), appt_date.end(), ' '), appt_date.end());

            for (int i = 0; i < patient_count; ++i) {
                if (patients[i].id == pid) {
                    patients[i].apt.appointment_date = appt_date;
                    patients[i].apt.description = appt_descr;
                    break;
                }
            }
        }
        appointmentCheck.close();
    }

    while (true) {
        int choice1;
        cout << "\nWelcome to the Hospital Management System" << endl;
        cout << "1. Patient Management" << endl;
        cout << "2. Staff Management" << endl;
        cout << "3. Lab and Equipment Management" << endl;
        cout << "4. Pharmacy Management" << endl;
        cout << "5. Billing Management" << endl;
        cout << "6. Reports and Statistics" << endl;
        cout << "7. Feedback" << endl;
        cout << "8. Exit" << endl;
        cout << "Please enter your choice: ";
        cin >> choice1;
        if (switchInputCheck()) continue;

        switch (choice1) {
            case 1: {
                cout << "Patient Management" << endl;
                int choice2;
                cout << "1. Patient Registration" << endl;
                cout << "2. Schedule Appointment" << endl;
                cout << "3. Check Appointment Records" << endl;
                cout << "4. Electronic Medical Records" << endl;
                cout << "5. Exit" << endl;
                cout << "Please enter your choice: ";
                cin >> choice2;
                if (switchInputCheck()) continue;

                switch (choice2) {
                    case 1: {
                        cout << "Patient Registration" << endl;
                        if (patient_count < MAX_RECORDS) {
                            cout << "Enter Patient Name: ";
                            cin.ignore();
                            getline(cin, patients[patient_count].name);

                            cout << "Enter Patient ID: ";
                            cin >> patients[patient_count].id;

                            bool exists = false;
                            for (int i = 0; i < patient_count; i++) {
                                if (patients[i].id == patients[patient_count].id) {
                                    exists = true;
                                    break;
                                }
                            }
                            if (exists) {
                                cout << "Patient ID already exists. Please enter a different ID." << endl;
                                break;
                            }

                            cout << "Enter Patient Age: ";
                            cin >> patients[patient_count].age;
                            fstream patient_file;
                            patient_file.open("Patient Record.txt", ios::app);
                            if (patient_file.is_open()) {
                                if (patient_count == 0) {
                                    patient_file << left;
                                    patient_file << setw(32) << "Patient Name" << "\t"
                                                 << setw(10) << "ID" << "\t"
                                                 << setw(3) << "Age" << "\n";
                                    fstream appointment_file;
                                    appointment_file.open("Appointments.txt", ios::out);
                                    if (appointment_file.is_open()) {
                                        appointment_file << left;
                                        appointment_file << setw(10) << "Patient ID" << "\t"
                                                         << setw(20) << "Appointment Date" << "\t"
                                                         << setw(100) << "Description" << endl;
                                        appointment_file.close();
                                    }
                                    else {
                                        cout << "Failed to open Appointments.txt";
                                        return 1;
                                    }
                                }

                                patient_file << left;
                                patient_file << setw(32) << patients[patient_count].name << "\t"
                                             << setw(10) << patients[patient_count].id << "\t"
                                             << setw(3) << patients[patient_count].age << "\n";
                                patient_file.close();
                            }

                            cout << "Patient registered successfully!" << endl;
                            cout << "Patient ID: " << patients[patient_count].id << endl;
                            patient_count++;
                        } else {
                            cout << "Patient records are full." << endl;
                        }
                        break;
                    }
                    case 2: {
                        cout << "Schedule Appointment" << endl;
                        cout << "Enter Patient ID: ";
                        cin >> patient_id;
                        bool found = false;
                        for (int i = 0; i < patient_count; i++) {
                            if (patients[i].id == patient_id) {
                                found = true;
                                cout << "Enter Appointment Date (YYYY-MM-DD): ";
                                string date_input;
                                cin >> date_input;
                                regex date_pattern(R"(\d{4}-\d{2}-\d{2})");
                                while (!regex_match(date_input, date_pattern)) {
                                    cout << "Invalid date format. Please enter the date in YYYY-MM-DD format: ";
                                    cin >> date_input;
                                }
                                patients[i].apt.appointment_date = date_input;
                                cout << "Enter a brief description of the appointment: ";
                                cin.ignore();
                                getline(cin, patients[i].apt.description);

                                fstream set_appointment("Appointments.txt", ios::app);
                                if (set_appointment.is_open()) {
                                    set_appointment << left;
                                    set_appointment << setw(10) << patients[i].id << '\t'
                                                    << setw(20) << patients[i].apt.appointment_date << '\t'
                                                    << setw(150) << patients[i].apt.description << '\n';
                                    cout << "Appointment scheduled successfully!" << endl;
                                    set_appointment.close();
                                } else {
                                    cout << "Failed to schedule appointment, try again!" << endl;
                                }
                                break;
                            }
                        }
                        if (!found) {
                            cout << "Patient not found." << endl;
                        }
                        break;
                    }
                    case 3: {
                        cout << "Check Appointment Records" << endl;
                        cout << "Enter Patient ID to view appointment records: ";
                        cin >> patient_id;
                        bool found = false;
                        for (int i = 0; i < patient_count; i++) {
                            if (patients[i].id == patient_id) {
                                found = true;
                                cout << "Patient ID: " << patients[i].id << '\n'
                                     << "Patient Name: " << patients[i].name << '\n';
                                if (patients[i].apt.appointment_date.empty()) {
                                    cout << "No appointment scheduled." << '\n';
                                } else {
                                    cout << "Appointment Date: " << patients[i].apt.appointment_date << '\n';
                                }
                                break;
                            }
                        }
                        if (!found) {
                            cout << "No records found for this Patient ID." << endl;
                        }
                        break;
                    }
                    case 4:
                        cout << "Electronic Medical Records\n" << endl;
                        cout << "Which record would you like to see\n";
                        cout << "1. Patient Record\n"
                             << "2. Appointment Record\n"
                             << "3. Exit\n";
                        int choice9;
                        cin >> choice9;
                        if(cin.fail()){
                            cout << "Invalid Input! Try Again.\n";
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        }
                        switch(choice9){
                            case 1:
                                cout << left;
                                cout << setw(32) << "Patient Name" << " | ";
                                cout << setw(10) << "ID" << " | "
                                     << setw(3)  << "Age\n";

                                for(int i = 0; i < patient_count; i++){
                                    cout << left;
                                    cout << setw(32) << patients[i].name << " | "
                                         << setw(10) << patients[i].id << " | "
                                         << setw(3)  << patients[i].age << '\n';
                                }
                                break;
                            case 2:
                                cout << left;
                                cout << setw(32) << "Name" << " | "
                                     << setw(10) << "ID" << " | "
                                     << setw(20) << "Appointment Date" << " | "
                                     << setw(150) << "Description" <<'\n';
                                for(int i = 0; i < patient_count; i++){
                                    cout << left;
                                    cout << setw(32) << patients[i].name << " | "
                                         << setw(10) << patients[i].id << " | "
                                         << setw(20) << patients[i].apt.appointment_date << " | "
                                         << setw(100) << patients[i].apt.description << endl;
                                }
                                break;
                            case 3:
                                cout << "Exiting the program...";
                                return 0;
                            default:
                                cout << "Invalid choice. Please try again.";
                        }
                        break;
                    case 5:
                        cout << "Exiting..." << endl;
                        return 0; // Exit the program
                    default:
                        cout << "Invalid choice. Please try again." << endl;
                }
                break;
            }

            case 2:
                staff_menu();
                break;

            case 3:
                lab_and_equipment_menu();
                break;

            case 4:
                pharmacy_menu();
                break;

            case 5:
                while (true)
                {
                    int choice4;
                    cout << "\n========== Billing Management ==========" << endl;
                    cout << "1. Generate Bill" << endl;
                    cout << "2. Insurance Claims" << endl;
                    cout << "3. Payment Processing" << endl;
                    cout << "4. View All Billing Records" << endl;
                    cout << "5. Exit to Main Menu" << endl;
                    cout << "========================================" << endl;
                    cout << "Please enter your choice: ";
                    cin >> choice4;

                    switch (choice4)
                    {
                        case 1:
                            cout << "\n--- Generate Bill ---" << endl;
                            cout << "Enter Patient ID: ";
                            cin >> billings[billing_count].patient_id;

                        {
                            bool patient_found = false;
                            for (int i = 0; i < patient_count; i++)
                            {
                                if (patients[i].id == billings[billing_count].patient_id)
                                {
                                    patient_found = true;
                                    break;
                                }
                            }

                            if (!patient_found)
                            {
                                cout << "Patient not found. Please register the patient first." << endl;
                                break;
                            }

                            cout << "Enter Bill Amount: ";
                            while (!(cin >> billings[billing_count].amount) || billings[billing_count].amount <= 0)
                            {
                                cout << "Invalid amount. Please enter a positive number: ";
                                cin.clear();
                                cin.ignore();
                            }

                            billings[billing_count].status = "Unpaid";

                            fstream billingFile("Billing Records.txt", ios::in | ios::out | ios::app);
                            if (billingFile.is_open())
                            {
                                billingFile.seekp(0, ios::end);
                                if (billingFile.tellp() == 0)
                                {
                                    billingFile << "Patient ID\tAmount\tStatus\n";
                                }
                                billingFile << billings[billing_count].patient_id << "\t"
                                            << fixed << setprecision(2) << billings[billing_count].amount << "\t"
                                            << billings[billing_count].status << "\n";
                                billingFile.close();
                            }
                            else
                            {
                                cout << "Error: Unable to open billing file." << endl;
                            }

                            cout << "Bill generated successfully!" << endl;
                            billing_count++;
                        }
                            break;

                        case 2:
                            cout << "\n--- Insurance Claims ---" << endl;
                            cout << "Enter Patient ID: ";
                            cin >> patient_id;
                        {
                            bool bill_found = false;
                            for (int i = 0; i < billing_count; i++)
                            {
                                if (billings[i].patient_id == patient_id)
                                {
                                    bill_found = true;
                                    cout << "Processing insurance claim for Patient ID: " << patient_id << endl;
                                    cout << "Bill Amount: " << fixed << setprecision(2) << billings[i].amount << endl;
                                    cout << "Insurance claim approved for the full amount." << endl;
                                    billings[i].status = "Paid (Insurance)";
                                    break;
                                }
                            }

                            if (!bill_found)
                            {
                                cout << "No bill found for the given Patient ID." << endl;
                            }
                        }
                            break;

                        case 3:
                            cout << "\n--- Payment Processing ---" << endl;
                            cout << "Enter Patient ID: ";
                            cin >> patient_id;
                        {
                            bool bill_found = false;
                            for (int i = 0; i < billing_count; i++)
                            {
                                if (billings[i].patient_id == patient_id)
                                {
                                    bill_found = true;
                                    cout << "Processing payment for Patient ID: " << patient_id << endl;
                                    cout << "Bill Amount: " << fixed << setprecision(2) << billings[i].amount << endl;

                                    float payment;
                                    cout << "Enter payment amount: ";
                                    while (!(cin >> payment) || payment <= 0)
                                    {
                                        cout << "Invalid amount. Please enter a positive number: ";
                                        cin.clear();
                                        cin.ignore();
                                    }

                                    if (payment >= billings[i].amount)
                                    {
                                        cout << "Payment successful! Change: " << fixed << setprecision(2) << (payment - billings[i].amount) << endl;
                                        billings[i].status = "Paid";
                                    }
                                    else
                                    {
                                        cout << "Insufficient payment. Please pay the full amount." << endl;
                                    }
                                    break;
                                }
                            }

                            if (!bill_found)
                            {
                                cout << "No bill found for the given Patient ID." << endl;
                            }
                        }
                            break;

                        case 4:
                            cout << "\n--- View All Billing Records ---" << endl;
                            if (billing_count == 0)
                            {
                                cout << "No billing records found." << endl;
                            }
                            else
                            {
                                cout << left << setw(15) << "Patient ID"
                                     << setw(10) << "Amount"
                                     << setw(15) << "Status" << endl;
                                cout << "----------------------------------------" << endl;
                                for (int i = 0; i < billing_count; i++)
                                {
                                    cout << left << setw(15) << billings[i].patient_id
                                         << setw(10) << fixed << setprecision(2) << billings[i].amount
                                         << setw(15) << billings[i].status << endl;
                                }
                            }
                            break;

                        case 5:
                            cout << "Exiting Billing Management..." << endl;
                            break;

                        default:
                            cout << "Invalid choice. Please try again." << endl;
                    }

                    char next_action;
                    cout << "\nWould you like to return to Billing Management (B) or Main Menu (M)? ";
                    cin >> next_action;
                    if (next_action == 'M' || next_action == 'm')
                    {
                        break;
                    }
                }
                break;

            case 6:
            {
                cout << "\n=== Reports and Statistics ===" << endl;
                int choice5;
                do {
                    cout << "\n1. Patient Statistics" << endl;
                    cout << "2. Staff Performance" << endl;
                    cout << "3. Financial Report" << endl;
                    cout << "4. Return to Main Menu" << endl;
                    cout << "Please enter your choice: ";
                    cin >> choice5;

                    switch (choice5)
                    {
                        case 1: {
                            // Patient Statistics
                            cout << "\n--- PATIENT STATISTICS ---" << endl;
                            cout << "Total Registered Patients: " << patient_count << endl;

                            // Age distribution
                            cout << "\nAge Distribution:" << endl;
                            int ageGroups[4] = {0}; // 0-18, 19-35, 36-60, 61+
                            for (int i = 0; i < patient_count; i++) {
                                if (patients[i].age <= 18) ageGroups[0]++;
                                else if (patients[i].age <= 35) ageGroups[1]++;
                                else if (patients[i].age <= 60) ageGroups[2]++;
                                else ageGroups[3]++;
                            }

                            cout << "Children (0-18):    " << setw(4) << ageGroups[0] << " patients" << endl;
                            cout << "Adults (19-35):    " << setw(4) << ageGroups[1] << " patients" << endl;
                            cout << "Middle-aged (36-60):" << setw(4) << ageGroups[2] << " patients" << endl;
                            cout << "Seniors (61+):     " << setw(4) << ageGroups[3] << " patients" << endl;

                            // Appointment statistics
                            int withAppointments = 0;
                            for (int i = 0; i < patient_count; i++) {
                                if (!patients[i].apt.appointment_date.empty()) {
                                    withAppointments++;
                                }
                            }
                            cout << "\nPatients with appointments: " << withAppointments << "/" << patient_count
                                 << " (" << fixed << setprecision(1)
                                 << (patient_count > 0 ? (withAppointments * 100.0 / patient_count) : 0)
                                 << "%)" << endl;
                            break;
                        }

                        case 2: {
                            // Staff Performance
                            cout << "\n--- STAFF PERFORMANCE ---" << endl;
                            cout << "Total Staff Members: " << staff_list.size() << endl;

                            // Department efficiency (simplified - assumes more staff = more capacity)
                            cout << "\nDepartment Staffing:" << endl;
                            map<string, int> deptCount;
                            for (const auto& s : staff_list) {
                                deptCount[s.department]++;
                            }

                            for (const auto& dept : deptCount) {
                                cout << left << setw(15) << dept.first << ": "
                                     << setw(3) << dept.second << " staff ("
                                     << fixed << setprecision(1)
                                     << (!staff_list.empty() ? (dept.second * 100.0 / staff_list.size()) : 0) // NOLINT(*-narrowing-conversions)
                                     << "%)" << endl;
                            }

                            // Lab technician performance (if available)
                            if (!lab_results.empty()) {
                                cout << "\nLab Technician Performance:" << endl;
                                map<string, int> techTests;
                                for (const auto& lr : lab_results) {
                                    techTests[lr.technician]++;
                                }

                                for (const auto& tech : techTests) {
                                    cout << left << setw(20) << tech.first << ": "
                                         << tech.second << " tests conducted" << endl;
                                }
                            }
                            break;
                        }

                        case 3: {
                            // Financial Report
                            cout << "\n--- FINANCIAL REPORT ---" << endl;

                            double totalBilled = 0.0;
                            double totalPaid = 0.0;
                            int unpaidCount = 0;

                            for (int i = 0; i < billing_count; i++) {
                                totalBilled += billings[i].amount;
                                if (billings[i].status.find("Paid") != string::npos) {
                                    totalPaid += billings[i].amount;
                                } else {
                                    unpaidCount++;
                                }
                            }

                            cout << fixed << setprecision(2);
                            cout << "Total Revenue:     $" << setw(10) << totalBilled << endl;
                            cout << "Amount Collected:  $" << setw(10) << totalPaid << endl;
                            cout << "Outstanding:       $" << setw(10) << (totalBilled - totalPaid) << endl;
                            cout << "Unpaid Bills:      " << setw(10) << unpaidCount << endl;

                            // Payment types
                            if (billing_count > 0) {
                                cout << "\nPayment Distribution:" << endl;
                                cout << "Collected: " << (totalPaid/totalBilled)*100 << "%" << endl;
                                cout << "Outstanding: " << ((totalBilled-totalPaid)/totalBilled)*100 << "%" << endl;
                            }
                            break;
                        }

                        case 4:
                            cout << "Returning to Main Menu..." << endl;
                            break;

                        default:
                            cout << "Invalid choice. Please try again." << endl;
                    }
                } while (choice5 != 4);
                break;
            }

            case 7: {
                cout << "Feedback" << endl;
                int choice6;
                cout << "1. Patient Feedback" << endl;
                cout << "2. Staff Feedback on Management" << endl;
                cout << "3. Exit" << endl;
                cout << "Please enter your choice: ";
                cin >> choice6;

                if (switchInputCheck()) continue;

                switch (choice6) {
                    case 1: {
                        cout << "Patient Feedback" << endl;
                        string pid;
                        cout << "Enter Patient ID: ";
                        cin >> pid;

                        bool found_patient = false;
                        for (int i = 0; i < patient_count; i++) {
                            if (patients[i].id == pid) {
                                found_patient = true;
                                Feedback fb;
                                fb.user_id = pid;

                                cout << "Rate our service (1-5): ";
                                while (!(cin >> fb.rating) || fb.rating < 1 || fb.rating > 5) {
                                    cout << "Invalid! Enter 1-5: ";
                                    cin.clear();
                                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                }

                                cin.ignore();
                                cout << "Comments (optional): ";
                                getline(cin, fb.comment);

                                // Get current date
                                time_t now = time(nullptr);
                                tm* t = localtime(&now);
                                char buf[20];
                                strftime(buf, sizeof(buf), "%Y-%m-%d", t);
                                fb.date = buf;

                                // Save to file
                                fstream file("Feedback.txt", ios::app);
                                if (file.is_open()) {
                                    if (file.tellp() == 0)
                                        file << "ID\tType\tRating\tComment\tDate\n";

                                    file << pid << "\tPatient\t"
                                         << fb.rating << "\t"
                                         << fb.comment << "\t"
                                         << fb.date << "\n";
                                    cout << "Thank you!\n";
                                }
                                break;
                            }
                        }
                        if (!found_patient) {
                            cout << "Patient not found!\n";
                        }
                        break;
                    }

                    case 2: {
                        cout << "Staff Feedback on Management" << endl;
                        string sid;
                        cout << "Enter Staff ID: ";
                        cin >> sid;

                        bool found_staff = false;
                        for (const auto& s : staff_list) {
                            if (to_string(s.id) == sid) {
                                found_staff = true;
                                Feedback fb;
                                fb.user_id = sid;

                                cout << "Rate management (1-5): ";
                                while (!(cin >> fb.rating) || fb.rating < 1 || fb.rating > 5) {
                                    cout << "Invalid! Enter 1-5: ";
                                    cin.clear();
                                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                }

                                cin.ignore();
                                cout << "Suggestions (optional): ";
                                getline(cin, fb.comment);

                                // Get current date
                                time_t now = time(nullptr);
                                tm* t = localtime(&now);
                                char buf[20];
                                strftime(buf, sizeof(buf), "%Y-%m-%d", t);
                                fb.date = buf;

                                // Save to file
                                fstream file("Feedback.txt", ios::app);
                                if (file.is_open()) {
                                    if (file.tellp() == 0)
                                        file << "ID\tType\tRating\tComment\tDate\n";

                                    file << sid << "\tStaff\t"
                                         << fb.rating << "\t"
                                         << fb.comment << "\t"
                                         << fb.date << "\n";
                                    cout << "Thank you!\n";
                                }
                                break;
                            }
                        }
                        if (!found_staff) {
                            cout << "Staff not found!\n";
                        }
                        break;
                    }

                    case 3:
                        cout << "Exiting Feedback menu..." << endl;
                        break;

                    default:
                        cout << "Invalid choice. Please try again." << endl;
                }
                break;
            }
            case 8:
                cout << "Exiting..." << endl;
                return 0;

            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
}