// Placeholder functions
void load_staff_data() {}
void load_medicine_data() {}
void initializeDepartments() {}

vector<Staff> staff_list;
vector<Equipment> equipments;
vector<LabResult> lab_results;
vector<Medicine> pharmacy;

void add_staff() {
    Staff s;
    cout << "Enter Staff ID: "; cin >> s.id;
    cin.ignore();
    cout << "Enter Name: "; getline(cin, s.name);
    cout << "Enter Department: "; getline(cin, s.department);
    cout << "Enter Shift (Morning/Evening/Night): "; getline(cin, s.shift);
    staff_list.push_back(s);
    cout << "Staff added.\n";
}

void show_staff_by_id() {
    int id;
    cout << "Enter Staff ID: "; cin >> id;
    for (const auto& s : staff_list) {
        if (s.id == id) {
            cout << "ID: " << s.id << ", Name: " << s.name
                 << ", Department: " << s.department << ", Shift: " << s.shift << endl;
            return;
        }
    }
    cout << "Staff not found.\n";
}

void remove_staff() {
    int id;
    cout << "Enter Staff ID to remove: "; cin >> id;
    for (auto it = staff_list.begin(); it != staff_list.end(); ++it) {
        if (it->id == id) {
            staff_list.erase(it);
            cout << "Staff removed.\n";
            return;
        }
    }
    cout << "Staff not found.\n";
}

void staff_statistics() {
    map<string, int> department_count;
    map<string, map<string, int>> shift_count;
    for (const auto& s : staff_list) {
        department_count[s.department]++;
        shift_count[s.department][s.shift]++;
    }
    cout << "\nStaff Count by Department:\n";
    for (const auto& dept : department_count) {
        cout << dept.first << ": " << dept.second << endl;
    }
    cout << "\nStaff Shift Distribution by Department:\n";
    for (const auto& dept : shift_count) {
        cout << dept.first << ":\n";
        for (const auto& shift : dept.second) {
            cout << "  " << shift.first << ": " << shift.second << endl;
        }
    }
}

void staff_menu() {
    int ch;
    do {
        cout << "\n-- Staff Management --\n1. Add Staff\n2. Show Staff by ID\n3. Remove Staff\n4. View Statistics\n5. Back\nChoice: ";
        cin >> ch;
        switch (ch) {
            case 1: add_staff(); break;
            case 2: show_staff_by_id(); break;
            case 3: remove_staff(); break;
            case 4: staff_statistics(); break;
            default: cout << "Invalid Input!";
        }
    } while (ch != 5);
}

void add_lab_result() {
    LabResult l;
    cout << "Enter Patient ID: "; cin >> l.patient_id;
    cin.ignore();
    cout << "Test Type (CBC/MRI/CT/Blood Test/X-ray): "; getline(cin, l.test_type);
    cout << "Enter Result: "; getline(cin, l.result);
    cout << "Technician Name: "; getline(cin, l.technician);
    l.date = "2025-05-11"; // Placeholder for current date
    lab_results.push_back(l);
    cout << "Result saved.\n";
}

void view_lab_results_by_patient() {
    string pid;
    cout << "Enter Patient ID: ";
    cin >> pid;
    bool found = false;
    for (const auto& l : lab_results) {
        if (l.patient_id == pid) {
            cout << "Test: " << l.test_type
                 << "\nResult: " << l.result
                 << "\nTechnician: " << l.technician
                 << "\nDate: " << l.date << "\n\n";
            found = true;
        }
    }
    if (!found) cout << "No tests found for this patient.\n";
}

void count_tests_by_category() {
    map<string, int> categories;
    for (const auto& l : lab_results) {
        categories[l.test_type]++;
    }
    cout << "Test Counts by Category:\n";
    vector<pair<string, int>> sorted(categories.begin(), categories.end());
    sort(sorted.begin(), sorted.end());
    for (const auto& category : sorted) {
        cout << category.first << ": " << category.second << endl;
    }
}

void add_equipment() {
    Equipment e;
    cin.ignore(); // ensure no leftover input
    cout << "Enter Equipment Name: "; getline(cin, e.name);
    cout << "Enter Department: "; getline(cin, e.department);
    cout << "Enter Quantity: "; cin >> e.quantity;
    equipments.push_back(e);
    cout << "Equipment added.\n";
}

void view_equipment_by_department() {
    string dept;
    cin.ignore();
    cout << "Enter Department: "; getline(cin, dept);
    bool found = false;
    for (const auto& e : equipments) {
        if (e.department == dept) {
            cout << "Name: " << e.name << "\nQuantity: " << e.quantity << endl;
            found = true;
        }
    }
    if (!found) cout << "No equipment found in this department.\n";
}

void lab_and_equipment_menu() {
    int choice;
    do {
        cout << "\n-- Lab and Equipment Management --\n";
        cout << "1. Add Lab Result\n2. View Lab Results by Patient\n3. Count Tests by Category\n4. Add Equipment\n5. View Equipment by Department\n6. Back\nChoice: ";
        cin >> choice;

        switch (choice) {
            case 1: add_lab_result(); break;
            case 2: view_lab_results_by_patient(); break;
            case 3: count_tests_by_category(); break;
            case 4: add_equipment(); break;
            case 5: view_equipment_by_department(); break;
            case 6: break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 6);
}

void view_medicines() {
    for (const auto& m : pharmacy) {
        cout << "Medicine: " << m.name << ", Quantity: " << m.quantity << endl;
    }
}

void check_medicine_availability() {
    string name;
    cin.ignore();
    cout << "Enter Medicine Name: "; getline(cin, name);
    for (const auto& m : pharmacy) {
        if (m.name == name) {
            cout << "Available Quantity: " << m.quantity << endl;
            return;
        }
    }
    cout << "Medicine not found.\n";
}

void dispense_medicine() {
    string name;
    int qty;
    cin.ignore();
    cout << "Enter Medicine Name: "; getline(cin, name);
    cout << "Enter Quantity to Dispense: "; cin >> qty;
    for (auto& m : pharmacy) {
        if (m.name == name) {
            if (m.quantity >= qty) {
                m.quantity -= qty;
                cout << "Medicine dispensed.\n";
            } else {
                cout << "Insufficient quantity.\n";
            }
            return;
        }
    }
    cout << "Medicine not found.\n";
}

void add_medicine() {
    Medicine m;
    cin.ignore();
    cout << "Enter Medicine Name: "; getline(cin, m.name);
    cout << "Enter Quantity: "; cin >> m.quantity;
    pharmacy.push_back(m);
    cout << "Medicine added.\n";
}

void remove_medicine() {
    string name;
    cin.ignore();
    cout << "Enter Medicine Name to Remove: "; getline(cin, name);
    for (auto it = pharmacy.begin(); it != pharmacy.end(); ++it) {
        if (it->name == name) {
            pharmacy.erase(it);
            cout << "Medicine removed.\n";
            return;
        }
    }
    cout << "Medicine not found.\n";
}

void pharmacy_menu() {
    int choice;
    do {
        cout << "\n-- Pharmacy Management --\n";
        cout << "1. View Medicines\n2. Check Medicine Availability\n3. Dispense Medicine\n4. Add Medicine\n5. Remove Medicine\n6. Back\nChoice: ";
        cin >> choice;

        switch (choice) {
            case 1: view_medicines(); break;
            case 2: check_medicine_availability(); break;
            case 3: dispense_medicine(); break;
            case 4: add_medicine(); break;
            case 5: remove_medicine(); break;
            case 6: break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 6);
}

bool switchInputCheck() {
    if (cin.fail()) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid choice. Please try again." << endl;
        return true;
    }
    return false;
}