using namespace std;
struct appointment {
    string appointment_date, description;
};

// Placeholder structs to prevent compilation error
struct patient {
    string id;
    string name;
    int age{};
    appointment apt;
};
